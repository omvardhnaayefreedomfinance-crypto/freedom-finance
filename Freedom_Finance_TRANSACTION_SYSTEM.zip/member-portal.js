const key='ff_member_session';
const dataKey='ff_demo_investment';

document.addEventListener('DOMContentLoaded',()=>{
 const login=document.getElementById('loginForm');
 if(login){login.addEventListener('submit',e=>{e.preventDefault();const email=document.getElementById('email').value.trim();sessionStorage.setItem(key,email);location.href='member-dashboard.html';});}
 const email=sessionStorage.getItem(key);
 const memberEmail=document.getElementById('memberEmail');
 if(memberEmail){if(!email){location.href='member-login.html';return;} memberEmail.textContent=email;loadInvestment();}
 const logout=document.getElementById('logout');
 if(logout) logout.onclick=()=>{sessionStorage.removeItem(key);location.href='member-login.html';};
 document.querySelectorAll('.buy').forEach(btn=>btn.onclick=()=>{localStorage.setItem('ff_selected_plan',btn.dataset.plan);location.href='payment-instructions.html';});
 const chosen=document.getElementById('chosenPlan');
 if(chosen) chosen.textContent=(localStorage.getItem('ff_selected_plan')||'Plan')+' — Payment Request';
 const create=document.getElementById('createRequest');
 if(create) create.onclick=()=>{const amount=Number(document.getElementById('payAmount').value);if(!amount||amount<1){alert('Please enter a valid amount.');return;}const email=sessionStorage.getItem(key);const plan=localStorage.getItem('ff_selected_plan')||'Plan';const ref='FF-'+Date.now();localStorage.setItem(dataKey,JSON.stringify({email,plan,amount,status:'Payment Pending',reference:ref,startDate:'Pending verification',endDate:'Pending verification',returnText:'As per approved plan terms'}));document.getElementById('requestResult').textContent='Request created: '+ref+'. Production payment verification must happen on the secure backend.';};
});
function loadInvestment(){
 const raw=localStorage.getItem(dataKey);if(!raw)return;
 const d=JSON.parse(raw);
 const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v};
 set('plan',d.plan);set('amount','₹'+Number(d.amount).toLocaleString('en-IN'));set('status',d.status);set('ref',d.reference);
 const details=document.getElementById('details');
 if(details)details.innerHTML='<p><b>Plan:</b> '+d.plan+'</p><p><b>Amount:</b> ₹'+Number(d.amount).toLocaleString('en-IN')+'</p><p><b>Start:</b> '+d.startDate+'</p><p><b>End:</b> '+d.endDate+'</p><p><b>Return:</b> '+d.returnText+'</p><p><b>Status:</b> '+d.status+'</p><p><b>Reference:</b> '+d.reference+'</p>';
}