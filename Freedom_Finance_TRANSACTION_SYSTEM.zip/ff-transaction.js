/* Freedom Finance transaction/maturity prototype */
function ffGetUser(){try{return JSON.parse(localStorage.getItem("ffdemo")||"null")}catch(e){return null}}
function ffGetTransactions(){try{return JSON.parse(localStorage.getItem("ffTransactions")||"[]")}catch(e){return []}}
function ffSaveTransaction(tx){const a=ffGetTransactions();a.unshift(tx);localStorage.setItem("ffTransactions",JSON.stringify(a));return tx}
function ffCreateTransaction(plan,amount,reference){const n=new Date(),m=new Date(n);m.setFullYear(m.getFullYear()+1);const u=ffGetUser()||{};return ffSaveTransaction({id:"FF-"+Date.now(),customerEmail:u.email||"",customerName:u.name||"",plan:plan||"",amount:amount||"",reference:reference||"",paymentDate:n.toISOString(),startDate:n.toISOString().slice(0,10),maturityDate:m.toISOString().slice(0,10),paymentStatus:"Pending",withdrawalStatus:"Not Available"})}
function ffCanWithdraw(d){return new Date()>=new Date(d+"T23:59:59")}
function ffRequestWithdrawal(id){const a=ffGetTransactions(),i=a.findIndex(x=>x.id===id);if(i<0||!ffCanWithdraw(a[i].maturityDate))return false;a[i].withdrawalStatus="Requested";a[i].withdrawalRequestedAt=new Date().toISOString();localStorage.setItem("ffTransactions",JSON.stringify(a));return true}
