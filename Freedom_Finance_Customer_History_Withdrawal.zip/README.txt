FREEDOM FINANCE CUSTOMER HISTORY UPDATE

Replace ff-transaction.js and transactions.html with these files.

The transaction page shows customer email, plan, investment, profit, total, UTR/reference, payment status, start date and maturity date.
The REQUEST WITHDRAWAL button is always visible, but the request is accepted only on/after maturity.
Withdrawal requests are stored separately in ffWithdrawals and shown under WITHDRAWAL HISTORY.

IMPORTANT: This is a browser/localStorage prototype. GitHub Pages cannot provide a real shared customer database. For real multi-customer records and actual payouts, a secure backend/database and payment verification are required.

To create a transaction when the customer submits a UTR, call:
ffCreateTransaction(plan, amount, profit, total, reference);
Then redirect to transactions.html.
