(function(){
"use strict";
const $=id=>document.getElementById(id);
const read=(k,d)=>{try{let x=localStorage.getItem(k);return x?JSON.parse(x):d}catch(e){return d}};
const write=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN");
const user=()=>read("ffdemo",{})||{};
const txs=()=>read("ffTransactions",[]);
const withdrawals=()=>read("ffWithdrawals",[]);
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
function date(v){if(!v)return null;let d=new Date(v);if(!isNaN(d))return d;let p=String(v).split("/");return p.length===3?new Date(+p[2],+p[1]-1,+p[0]):null}
function eligible(t){let d=date(t.maturityDate);return d&&!isNaN(d)&&new Date()>=d}
function list(){let e=(user().email||"").toLowerCase();return txs().filter(t=>!e||String(t.customerEmail||"").toLowerCase()===e)}
function profit(t){return Number(t.withdrawalAmount??t.profit??0)}
function selected(){return list().find(t=>t.id===$("tx").value)}
function render(){
 let s=$("tx");s.innerHTML="";
 let a=list(), first=null;
 if(!a.length){s.innerHTML='<option value="">No transaction found</option>';$("amount").disabled=true;return}
 a.forEach(t=>{let o=document.createElement("option");o.value=t.id;o.textContent=(t.id||"Transaction")+" — "+(t.plan||"Plan")+" — "+money(profit(t))+(eligible(t)?" — Eligible":" — Locked");o.disabled=!eligible(t);s.appendChild(o);if(eligible(t)&&!first)first=t});
 if(first){s.value=first.id;$("amount").disabled=false;$("amount").max=profit(first);$("amount").value=profit(first)}else{$("amount").disabled=true}
 update()
}
function update(){
 let t=selected(),box=$("eligibility");if(!t){$("available").textContent=money(0);box.textContent="No eligible transaction is currently available.";return}
 let p=profit(t);
 if(eligible(t)){$("available").textContent=money(p);box.innerHTML='<span class="ok">Eligible for withdrawal.</span> Maximum: <b>'+money(p)+'</b>.';$("amount").disabled=false;$("amount").max=p}
 else{$("available").textContent=money(0);box.innerHTML='<span class="pending">Withdrawal locked until maturity.</span>';$("amount").disabled=true}
}
function duplicate(id){let e=(user().email||"").toLowerCase();return withdrawals().some(w=>w.transactionId===id&&String(w.customerEmail||"").toLowerCase()===e&&!["Rejected","Cancelled"].includes(w.status))}
function history(){
 let e=(user().email||"").toLowerCase(),a=withdrawals().filter(w=>!e||String(w.customerEmail||"").toLowerCase()===e).sort((x,y)=>(y.createdAtMs||0)-(x.createdAtMs||0));
 if(!a.length){$("history").innerHTML='<div class="muted">No withdrawal history found.</div>';$("latest").textContent="No request yet.";return}
 $("history").innerHTML="<table><tr><th>Withdrawal ID</th><th>Transaction</th><th>Plan</th><th>Amount</th><th>Mode</th><th>Status</th><th>Requested</th></tr>"+a.map(w=>"<tr><td>"+esc(w.id)+"</td><td>"+esc(w.transactionId)+"</td><td>"+esc(w.plan)+"</td><td>"+money(w.amount)+"</td><td>"+esc(w.mode)+"</td><td class='"+(w.status==="Completed"||w.status==="Approved"?"ok":w.status==="Rejected"?"bad":"pending")+"'>"+esc(w.status)+"</td><td>"+esc(w.requestedAt)+"</td></tr>").join("")+"</table>";
 let w=a[0];$("latest").innerHTML="<b>"+esc(w.status)+"</b><br><span class='muted'>"+esc(w.id)+" · "+money(w.amount)+" · "+esc(w.requestedAt)+"</span>"
}
$("tx").addEventListener("change",update);
$("form").addEventListener("submit",function(e){
 e.preventDefault();let t=selected();if(!t)return alert("No transaction selected.");if(!eligible(t))return alert("Transaction is not mature yet.");
 if(duplicate(t.id))return alert("A withdrawal request already exists for this transaction.");
 let max=profit(t),amount=Number($("amount").value);if(!amount||amount<=0||amount>max)return alert("Enter a valid amount up to "+money(max)+".");
 let u=user(),now=new Date(),w={id:"WD-"+Date.now(),transactionId:t.id,customerName:u.name||"Customer",customerEmail:u.email||t.customerEmail||"",plan:t.plan||"",amount,mode:$("mode").value,accountHolder:$("holder").value.trim(),accountNumber:$("account").value.trim(),ifsc:$("ifsc").value.trim().toUpperCase(),upi:$("upi").value.trim(),note:$("note").value.trim(),status:"Requested",requestedAt:now.toLocaleDateString("en-IN"),createdAt:now.toISOString(),createdAtMs:Date.now()};
 let a=withdrawals();a.unshift(w);write("ffWithdrawals",a);
 let all=txs(),i=all.findIndex(x=>x.id===t.id);if(i>=0){all[i].withdrawalStatus="Requested";all[i].withdrawalRequestedAt=w.requestedAt;write("ffTransactions",all)}
 $("result").style.display="block";$("result").innerHTML="<b>Withdrawal request created.</b><br>Request ID: "+esc(w.id)+"<br>Status: <span class='pending'>Requested</span>";
 render();history();
});
$("clear").onclick=()=>{$("form").reset();$("result").style.display="none";render()};
document.addEventListener("DOMContentLoaded",()=>{render();history()});
})();